<?php require_once 'usuario-verifica.php'; ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sistema Acadêmico</title>
</head>
<body>
<h1>Sistema Acadêmico</h1>
<ul>
    <li><a href="alunos-listar.php">Alunos</a></li>
    <li><a href="turmas-listar.php">Turmas</a></li>
    <li><a href="disc-listar.php">Disciplinas</a></li>
</ul>    
<a href="usuario-logout.php">Sair</a>
</body>
</html>